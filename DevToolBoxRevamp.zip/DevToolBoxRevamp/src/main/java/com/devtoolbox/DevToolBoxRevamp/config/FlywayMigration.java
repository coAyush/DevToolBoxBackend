package com.devtoolbox.DevToolBoxRevamp.config;

import org.flywaydb.core.Flyway;
import org.springframework.boot.flyway.autoconfigure.FlywayMigrationStrategy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FlywayMigration{

    @Bean
    public FlywayMigrationStrategy flywayMigrationStrategy(){
        return flyway->{
            flyway.repair();
            flyway.migrate();
        };
    }
}
